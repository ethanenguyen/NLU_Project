bert_buboqa.tar.gz is the source code for implenting Bert models over the BuboQA paper (https://github.com/castorini/BuboQA) 
bert_keqa.tar.gz is the source code for implenting Bert models over the KEQA paper (https://github.com/xhuang31/KEQA_WSDM19).

